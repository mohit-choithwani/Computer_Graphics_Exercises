precision mediump float;
 
varying vec3 color;

//out vec4 fragmentColor;

void main(void)
{ 
    gl_FragColor = vec4(1,0,0, 1.0);
}